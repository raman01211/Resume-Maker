import React, { Component } from 'react';
class Home extends Component {
  render() {
    return (
      <div className="Home">
        This is the homepage.
      </div>
    )
  }
}
export default Home;